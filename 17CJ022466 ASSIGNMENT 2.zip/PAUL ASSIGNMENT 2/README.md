# Choropleth Maps in Python with Plotly and Pandas

Short guide on how to make Choropleth Plots in Python with Plotly and Pandas. 
The 2016 population of Nigeria is used for illustration.

A video explanation can be found on my Youtube channel [@DevFaaizz](https://youtu.be/qM3Iqw0tEAs).